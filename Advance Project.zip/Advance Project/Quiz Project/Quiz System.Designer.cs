﻿using System;

namespace Quiz_Project
{
    partial class QuizSystem
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageLogin = new System.Windows.Forms.TabPage();
            this.tabPageAdmin = new System.Windows.Forms.TabPage();
            this.tabPageQuiz = new System.Windows.Forms.TabPage();
            this.tabPageResult = new System.Windows.Forms.TabPage();
            this.tabPageHistory = new System.Windows.Forms.TabPage();

            // Login Controls
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.lblWelcome = new System.Windows.Forms.Label();

            // Admin Controls
            this.dgvQuestions = new System.Windows.Forms.DataGridView();
            this.cmbSubjectAdmin = new System.Windows.Forms.ComboBox();
            this.txtQuestionText = new System.Windows.Forms.TextBox();
            this.txtOptA = new System.Windows.Forms.TextBox();
            this.txtOptB = new System.Windows.Forms.TextBox();
            this.txtOptC = new System.Windows.Forms.TextBox();
            this.txtOptD = new System.Windows.Forms.TextBox();
            this.cmbCorrectOption = new System.Windows.Forms.ComboBox();
            this.numPoints = new System.Windows.Forms.NumericUpDown();
            this.btnAddQuestion = new System.Windows.Forms.Button();
            this.btnUpdateQuestion = new System.Windows.Forms.Button();
            this.btnDeleteQuestion = new System.Windows.Forms.Button();
            this.btnClearFields = new System.Windows.Forms.Button();

            // Quiz Controls
            this.cmbSubjectQuiz = new System.Windows.Forms.ComboBox();
            this.btnStartQuiz = new System.Windows.Forms.Button();
            this.lblQuestionDisplay = new System.Windows.Forms.Label();
            this.rbOptA = new System.Windows.Forms.RadioButton();
            this.rbOptB = new System.Windows.Forms.RadioButton();
            this.rbOptC = new System.Windows.Forms.RadioButton();
            this.rbOptD = new System.Windows.Forms.RadioButton();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnSubmitQuiz = new System.Windows.Forms.Button();
            this.lblTimer = new System.Windows.Forms.Label();
            this.quizTimer = new System.Windows.Forms.Timer(this.components);

            // Result & History Controls
            this.dgvResultBreakdown = new System.Windows.Forms.DataGridView();
            this.btnBackToHome = new System.Windows.Forms.Button();
            this.dgvHistory = new System.Windows.Forms.DataGridView();
            this.btnRefreshHistory = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvQuestions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPoints)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultBreakdown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).BeginInit();
            this.tabControlMain.SuspendLayout();
            this.SuspendLayout();

            // tabControlMain Setup
            this.tabControlMain.Controls.Add(this.tabPageLogin);
            this.tabControlMain.Controls.Add(this.tabPageAdmin);
            this.tabControlMain.Controls.Add(this.tabPageQuiz);
            this.tabControlMain.Controls.Add(this.tabPageResult);
            this.tabControlMain.Controls.Add(this.tabPageHistory);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 0);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(984, 661);

            // Tab 1: LOGIN PAGE Layout
            this.tabPageLogin.BackColor = System.Drawing.Color.White;
            this.tabPageLogin.Controls.Add(this.txtUsername);
            this.tabPageLogin.Controls.Add(this.txtPassword);
            this.tabPageLogin.Controls.Add(this.btnLogin);
            this.tabPageLogin.Controls.Add(this.btnRegister);
            this.tabPageLogin.Controls.Add(this.lblWelcome);
            this.tabPageLogin.Text = "Authentication Portal";

            this.lblWelcome.Text = "QUIZ MANAGEMENT SYSTEM";
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.Location = new System.Drawing.Point(300, 100);
            this.lblWelcome.Size = new System.Drawing.Size(400, 40);

            this.txtUsername.Location = new System.Drawing.Point(350, 200);
            this.txtUsername.Size = new System.Drawing.Size(250, 30);
            this.txtUsername.Text = "student1";

            this.txtPassword.Location = new System.Drawing.Point(350, 250);
            this.txtPassword.Size = new System.Drawing.Size(250, 30);
            this.txtPassword.PasswordChar = '●';
            this.txtPassword.Text = "pass123";

            this.btnLogin.Text = "Login Securely";
            this.btnLogin.Location = new System.Drawing.Point(350, 310);
            this.btnLogin.Size = new System.Drawing.Size(115, 40);
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);

            this.btnRegister.Text = "Register Account";
            this.btnRegister.Location = new System.Drawing.Point(485, 310);
            this.btnRegister.Size = new System.Drawing.Size(115, 40);
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);

            // Tab 2: ADMIN PANEL Layout
            this.tabPageAdmin.Text = "Admin Control Panel";
            this.tabPageAdmin.Controls.Add(this.dgvQuestions);
            this.tabPageAdmin.Controls.Add(this.cmbSubjectAdmin);
            this.tabPageAdmin.Controls.Add(this.txtQuestionText);
            this.tabPageAdmin.Controls.Add(this.txtOptA);
            this.tabPageAdmin.Controls.Add(this.txtOptB);
            this.tabPageAdmin.Controls.Add(this.txtOptC);
            this.tabPageAdmin.Controls.Add(this.txtOptD);
            this.tabPageAdmin.Controls.Add(this.cmbCorrectOption);
            this.tabPageAdmin.Controls.Add(this.numPoints);
            this.tabPageAdmin.Controls.Add(this.btnAddQuestion);
            this.tabPageAdmin.Controls.Add(this.btnUpdateQuestion);
            this.tabPageAdmin.Controls.Add(this.btnDeleteQuestion);
            this.tabPageAdmin.Controls.Add(this.btnClearFields);

            this.dgvQuestions.Location = new System.Drawing.Point(20, 20);
            this.dgvQuestions.Size = new System.Drawing.Size(930, 280);
            this.dgvQuestions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvQuestions.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuestions_CellClick);

            this.cmbSubjectAdmin.Location = new System.Drawing.Point(20, 320);
            this.cmbSubjectAdmin.Size = new System.Drawing.Size(200, 25);

            this.txtQuestionText.Location = new System.Drawing.Point(240, 320);
            this.txtQuestionText.Size = new System.Drawing.Size(710, 50);

            this.txtOptA.Location = new System.Drawing.Point(20, 390); this.txtOptA.Size = new System.Drawing.Size(200, 25);
            this.txtOptB.Location = new System.Drawing.Point(250, 390); this.txtOptB.Size = new System.Drawing.Size(200, 25);
            this.txtOptC.Location = new System.Drawing.Point(480, 390); this.txtOptC.Size = new System.Drawing.Size(200, 25);
            this.txtOptD.Location = new System.Drawing.Point(710, 390); this.txtOptD.Size = new System.Drawing.Size(240, 25);

            this.cmbCorrectOption.Items.AddRange(new object[] { "A", "B", "C", "D" });
            this.cmbCorrectOption.Location = new System.Drawing.Point(20, 440);
            this.cmbCorrectOption.Size = new System.Drawing.Size(100, 25);

            this.numPoints.Location = new System.Drawing.Point(150, 440);
            this.numPoints.Size = new System.Drawing.Size(70, 25);
            this.numPoints.Value = 2;

            this.btnAddQuestion.Text = "Insert"; this.btnAddQuestion.Location = new System.Drawing.Point(240, 440); this.btnAddQuestion.Size = new System.Drawing.Size(100, 35);
            this.btnAddQuestion.Click += new System.EventHandler(this.btnAddQuestion_Click);

            this.btnUpdateQuestion.Text = "Modify"; this.btnUpdateQuestion.Location = new System.Drawing.Point(360, 440); this.btnUpdateQuestion.Size = new System.Drawing.Size(100, 35);
            this.btnUpdateQuestion.Click += new System.EventHandler(this.btnUpdateQuestion_Click);

            this.btnDeleteQuestion.Text = "Remove"; this.btnDeleteQuestion.Location = new System.Drawing.Point(480, 440); this.btnDeleteQuestion.Size = new System.Drawing.Size(100, 35);
            this.btnDeleteQuestion.Click += new System.EventHandler(this.btnDeleteQuestion_Click);

            this.btnClearFields.Text = "Reset Form"; this.btnClearFields.Location = new System.Drawing.Point(600, 440); this.btnClearFields.Size = new System.Drawing.Size(100, 35);
            this.btnClearFields.Click += new System.EventHandler(this.btnClearFields_Click);

            // Tab 3: EXAM RUNTIME (TAKE QUIZ) Layout
            this.tabPageQuiz.Text = "Examination Panel";
            this.tabPageQuiz.Controls.Add(this.cmbSubjectQuiz);
            this.tabPageQuiz.Controls.Add(this.btnStartQuiz);
            this.tabPageQuiz.Controls.Add(this.lblQuestionDisplay);
            this.tabPageQuiz.Controls.Add(this.rbOptA);
            this.tabPageQuiz.Controls.Add(this.rbOptB);
            this.tabPageQuiz.Controls.Add(this.rbOptC);
            this.tabPageQuiz.Controls.Add(this.rbOptD);
            this.tabPageQuiz.Controls.Add(this.btnPrevious);
            this.tabPageQuiz.Controls.Add(this.btnNext);
            this.tabPageQuiz.Controls.Add(this.btnSubmitQuiz);
            this.tabPageQuiz.Controls.Add(this.lblTimer);

            this.cmbSubjectQuiz.Location = new System.Drawing.Point(30, 30);
            this.cmbSubjectQuiz.Size = new System.Drawing.Size(250, 25);
            this.cmbSubjectQuiz.SelectedIndexChanged += new System.EventHandler(this.cmbSubjectQuiz_SelectedIndexChanged);

            this.btnStartQuiz.Text = "Initialize Exam";
            this.btnStartQuiz.Location = new System.Drawing.Point(300, 27);
            this.btnStartQuiz.Size = new System.Drawing.Size(120, 32);
            this.btnStartQuiz.Click += new System.EventHandler(this.btnStartQuiz_Click);

            this.lblTimer.Text = "Time Remaining: --";
            this.lblTimer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTimer.ForeColor = System.Drawing.Color.DarkRed;
            this.lblTimer.Location = new System.Drawing.Point(700, 30);
            this.lblTimer.Size = new System.Drawing.Size(250, 30);

            this.lblQuestionDisplay.Text = "Please pick a subject and initialize the quiz context.";
            this.lblQuestionDisplay.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblQuestionDisplay.Location = new System.Drawing.Point(30, 90);
            this.lblQuestionDisplay.Size = new System.Drawing.Size(900, 60);
            this.lblQuestionDisplay.AutoSize = true;

            this.rbOptA.Location = new System.Drawing.Point(40, 180); this.rbOptA.Size = new System.Drawing.Size(800, 30);
            this.rbOptB.Location = new System.Drawing.Point(40, 230); this.rbOptB.Size = new System.Drawing.Size(800, 30);
            this.rbOptC.Location = new System.Drawing.Point(40, 280); this.rbOptC.Size = new System.Drawing.Size(800, 30);
            this.rbOptD.Location = new System.Drawing.Point(40, 330); this.rbOptD.Size = new System.Drawing.Size(800, 30);

            this.btnPrevious.Text = "◀ Previous"; this.btnPrevious.Location = new System.Drawing.Point(40, 420); this.btnPrevious.Size = new System.Drawing.Size(120, 40);
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);

            this.btnNext.Text = "Next ▶"; this.btnNext.Location = new System.Drawing.Point(180, 420); this.btnNext.Size = new System.Drawing.Size(120, 40);
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);

            this.btnSubmitQuiz.Text = "Submit Final Paper";
            this.btnSubmitQuiz.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSubmitQuiz.ForeColor = System.Drawing.Color.White;
            this.btnSubmitQuiz.Location = new System.Drawing.Point(790, 420);
            this.btnSubmitQuiz.Size = new System.Drawing.Size(140, 40);
            this.btnSubmitQuiz.Visible = false;
            this.btnSubmitQuiz.Click += new System.EventHandler(this.btnSubmitQuiz_Click);

            this.quizTimer.Interval = 1000;
            this.quizTimer.Tick += new System.EventHandler(this.quizTimer_Tick);

            // Tab 4: LIVE METRICS & RESULTS
            this.tabPageResult.Text = "Live Performance Breakdown";
            this.tabPageResult.Controls.Add(this.dgvResultBreakdown);
            this.tabPageResult.Controls.Add(this.btnBackToHome);

            this.dgvResultBreakdown.Location = new System.Drawing.Point(20, 20);
            this.dgvResultBreakdown.Size = new System.Drawing.Size(930, 450);
            this.dgvResultBreakdown.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultBreakdown.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvResultBreakdown_CellFormatting);

            this.btnBackToHome.Text = "Return to Core Module";
            this.btnBackToHome.Location = new System.Drawing.Point(20, 490);
            this.btnBackToHome.Size = new System.Drawing.Size(200, 40);
            this.btnBackToHome.Click += new System.EventHandler(this.btnBackToHome_Click);

            // Tab 5: HISTORICAL RECORDS Logs
            this.tabPageHistory.Text = "Audit Logs & Archives";
            this.tabPageHistory.Controls.Add(this.dgvHistory);
            this.tabPageHistory.Controls.Add(this.btnRefreshHistory);

            this.dgvHistory.Location = new System.Drawing.Point(20, 20);
            this.dgvHistory.Size = new System.Drawing.Size(930, 450);
            this.dgvHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.btnRefreshHistory.Text = "Fetch Updates";
            this.btnRefreshHistory.Location = new System.Drawing.Point(20, 490);
            this.btnRefreshHistory.Size = new System.Drawing.Size(150, 40);
            this.btnRefreshHistory.Click += new System.EventHandler(this.btnRefreshHistory_Click);

            // Form Master Base Properties
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.tabControlMain);
            this.Name = "QuizSystem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Enterprise Quiz Engine V1.0";
            this.Load += new System.EventHandler(this.QuizSystem_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dgvQuestions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numPoints)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultBreakdown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).EndInit();
            this.tabControlMain.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageLogin;
        private System.Windows.Forms.TabPage tabPageAdmin;
        private System.Windows.Forms.TabPage tabPageQuiz;
        private System.Windows.Forms.TabPage tabPageResult;
        private System.Windows.Forms.TabPage tabPageHistory;

        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label lblWelcome;

        private System.Windows.Forms.DataGridView dgvQuestions;
        private System.Windows.Forms.ComboBox cmbSubjectAdmin;
        private System.Windows.Forms.TextBox txtQuestionText;
        private System.Windows.Forms.TextBox txtOptA;
        private System.Windows.Forms.TextBox txtOptB;
        private System.Windows.Forms.TextBox txtOptC;
        private System.Windows.Forms.TextBox txtOptD;
        private System.Windows.Forms.ComboBox cmbCorrectOption;
        private System.Windows.Forms.NumericUpDown numPoints;
        private System.Windows.Forms.Button btnAddQuestion;
        private System.Windows.Forms.Button btnUpdateQuestion;
        private System.Windows.Forms.Button btnDeleteQuestion;
        private System.Windows.Forms.Button btnClearFields;

        private System.Windows.Forms.ComboBox cmbSubjectQuiz;
        private System.Windows.Forms.Button btnStartQuiz;
        private System.Windows.Forms.Label lblQuestionDisplay;
        private System.Windows.Forms.RadioButton rbOptA;
        private System.Windows.Forms.RadioButton rbOptB;
        private System.Windows.Forms.RadioButton rbOptC;
        private System.Windows.Forms.RadioButton rbOptD;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnSubmitQuiz;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer quizTimer;

        private System.Windows.Forms.DataGridView dgvResultBreakdown;
        private System.Windows.Forms.Button btnBackToHome;
        private System.Windows.Forms.DataGridView dgvHistory;
        private System.Windows.Forms.Button btnRefreshHistory;
        private void cmbSubjectQuiz_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Yeh method missing tha jiski wajah se designer crash ho rha tha
        }
    }
}