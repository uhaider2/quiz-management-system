﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz_Project
{
    public partial class QuizSystem : Form
    {
        // Connection String - Optimized connection configurations mapping local server instance
        private readonly string connectionString = @"Server=.\SQLEXPRESS;Database=QuizSystemDB;Trusted_Connection=True;";

        // Runtime Session Context State Matrix
        private int loggedInUserId = 0;
        private string loggedInRole = "";
        private string loggedInUsername = "";

        // Quiz State Management Collections & Components
        private List<DataRow> quizQuestions = new List<DataRow>();
        private readonly Dictionary<int, string> userAnswers = new Dictionary<int, string>(); // Key: QuestionId, Value: Chosen Option ('A','B','C','D')
        private int currentQuestionIndex = 0;
        private int timeAllocated = 30; // 30 seconds limit per question frame
        private int currentActiveResultId = 0;

        public QuizSystem()
        {
            InitializeComponent();
        }

        private void QuizSystem_Load(object sender, EventArgs e)
        {
            ApplyInitialLockState();
            PopulateSystemConfigurations();
        }

        private void ApplyInitialLockState()
        {
            // Security Isolation Rule: Lock all analytical layout tabs until authentication confirms identity
            foreach (TabPage tab in tabControlMain.TabPages)
            {
                if (tab != tabPageLogin) tab.Enabled = false;
            }
            tabControlMain.SelectedTab = tabPageLogin;
        }

        private void PopulateSystemConfigurations()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string selectCmd = "SELECT SubjectId, SubjectName + ' [' + CourseCode + ']' AS FieldTitle FROM Subjects";
                    SqlDataAdapter da = new SqlDataAdapter(selectCmd, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Map quiz selection target dropdown elements
                    cmbSubjectQuiz.DataSource = dt;
                    cmbSubjectQuiz.DisplayMember = "FieldTitle";
                    cmbSubjectQuiz.ValueMember = "SubjectId";

                    // Clone schema structure map metadata for admin data isolation layout
                    DataTable dtAdminView = dt.Copy();
                    cmbSubjectAdmin.DataSource = dtAdminView;
                    cmbSubjectAdmin.DisplayMember = "FieldTitle";
                    cmbSubjectAdmin.ValueMember = "SubjectId";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database structure mapping failed during system load initialization context: " + ex.Message, "Runtime Link Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ================= TAB 1: AUTHENTICATION ROUTINES =================
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Input credentials missing.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string cmdText = "SELECT UserId, Username, Role FROM Users WHERE Username = @u AND Password = @p";
                SqlCommand cmd = new SqlCommand(cmdText, conn);
                cmd.Parameters.AddWithValue("@u", txtUsername.Text.Trim());
                cmd.Parameters.AddWithValue("@p", txtPassword.Text.Trim());

                try
                {
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            loggedInUserId = dr.GetInt32(0);
                            loggedInUsername = dr.GetString(1);
                            loggedInRole = dr.GetString(2);

                            lblWelcome.Text = $"Authenticated Principal: {loggedInUsername} [{loggedInRole}]";

                            // Re-evaluate application security visibility layout context rules
                            tabPageLogin.Enabled = false;
                            tabPageResult.Enabled = true;
                            tabPageHistory.Enabled = true;

                            if (loggedInRole.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                            {
                                tabPageAdmin.Enabled = true;
                                tabPageQuiz.Enabled = false;
                                tabControlMain.SelectedTab = tabPageAdmin;
                                FetchAdminRepositoryData();
                            }
                            else
                            {
                                tabPageAdmin.Enabled = false;
                                tabPageQuiz.Enabled = true;
                                tabControlMain.SelectedTab = tabPageQuiz;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid verification sequence returned. Check username/password configuration schema.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Authentication runtime infrastructure faulty: " + ex.Message, "Fatal IO Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Please structure new user parameter constraints before submission.", "Parameters Missing", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string insertText = "INSERT INTO Users (Username, Password, Role) VALUES (@u, @p, 'Student')";
                SqlCommand cmd = new SqlCommand(insertText, conn);
                cmd.Parameters.AddWithValue("@u", txtUsername.Text.Trim());
                cmd.Parameters.AddWithValue("@p", txtPassword.Text.Trim());

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("New application student entity created successfully. Proceed to login execution flow.", "Registry Confirmed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (SqlException ex) when (ex.Number == 2627)
                {
                    MessageBox.Show("Unique entity exception constraint mapped. Identity already configured within database index.", "Identity Colliding", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unexpected engine registration anomaly detected: " + ex.Message, "Engine Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // ================= TAB 2: ADMINISTRATIVE ENGINE CRUD OPERATIONS =================
        private void FetchAdminRepositoryData()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string selectAll = @"SELECT q.QuestionId, s.SubjectName, q.QuestionText, q.OptionA, q.OptionB, q.OptionC, q.OptionD, q.CorrectOption, q.Points 
                                         FROM Questions q JOIN Subjects s ON q.SubjectId = s.SubjectId";
                    SqlDataAdapter da = new SqlDataAdapter(selectAll, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvQuestions.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to pull repository runtime context data structures: " + ex.Message);
            }
        }

        private void btnAddQuestion_Click(object sender, EventArgs e)
        {
            if (cmbSubjectAdmin.SelectedValue == null || string.IsNullOrWhiteSpace(txtQuestionText.Text))
            {
                MessageBox.Show("Required administrative data fields cannot be blank.", "Data Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string insertQuery = @"INSERT INTO Questions (SubjectId, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Points) 
                                       VALUES (@sub, @txt, @optA, @optB, @optC, @optD, @corr, @pts)";
                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@sub", cmbSubjectAdmin.SelectedValue);
                cmd.Parameters.AddWithValue("@txt", txtQuestionText.Text.Trim());
                cmd.Parameters.AddWithValue("@optA", txtOptA.Text.Trim());
                cmd.Parameters.AddWithValue("@optB", txtOptB.Text.Trim());
                cmd.Parameters.AddWithValue("@optC", txtOptC.Text.Trim());
                cmd.Parameters.AddWithValue("@optD", txtOptD.Text.Trim());
                cmd.Parameters.AddWithValue("@corr", cmbCorrectOption.SelectedItem?.ToString() ?? "A");
                cmd.Parameters.AddWithValue("@pts", numPoints.Value);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    FetchAdminRepositoryData();
                    ClearAdminInputFields();
                    MessageBox.Show("Question mapped and saved inside database repository index context.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("Failed to push row entry layout: " + ex.Message); }
            }
        }

        private void btnUpdateQuestion_Click(object sender, EventArgs e)
        {
            if (dgvQuestions.CurrentRow == null) return;

            // Safe column matching selection pattern
            int targetedId = Convert.ToInt32(dgvQuestions.CurrentRow.Cells["QuestionId"].Value);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string updateText = @"UPDATE Questions SET SubjectId=@sub, QuestionText=@txt, OptionA=@optA, OptionB=@optB, OptionC=@optC, OptionD=@optD, CorrectOption=@corr, Points=@pts 
                                      WHERE QuestionId=@id";
                SqlCommand cmd = new SqlCommand(updateText, conn);
                cmd.Parameters.AddWithValue("@sub", cmbSubjectAdmin.SelectedValue);
                cmd.Parameters.AddWithValue("@txt", txtQuestionText.Text.Trim());
                cmd.Parameters.AddWithValue("@optA", txtOptA.Text.Trim());
                cmd.Parameters.AddWithValue("@optB", txtOptB.Text.Trim());
                cmd.Parameters.AddWithValue("@optC", txtOptC.Text.Trim());
                cmd.Parameters.AddWithValue("@optD", txtOptD.Text.Trim());
                cmd.Parameters.AddWithValue("@corr", cmbCorrectOption.SelectedItem?.ToString() ?? "A");
                cmd.Parameters.AddWithValue("@pts", numPoints.Value);
                cmd.Parameters.AddWithValue("@id", targetedId);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    FetchAdminRepositoryData();
                    ClearAdminInputFields();
                    MessageBox.Show("Database structural object entity records updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("Modification failed: " + ex.Message); }
            }
        }

        private void btnDeleteQuestion_Click(object sender, EventArgs e)
        {
            if (dgvQuestions.CurrentRow == null) return;
            int targetedId = Convert.ToInt32(dgvQuestions.CurrentRow.Cells["QuestionId"].Value);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string deleteText = "DELETE FROM Questions WHERE QuestionId = @id";
                SqlCommand cmd = new SqlCommand(deleteText, conn);
                cmd.Parameters.AddWithValue("@id", targetedId);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    FetchAdminRepositoryData();
                    ClearAdminInputFields();
                    MessageBox.Show("Object reference removed clean from identity collection data layers.", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex) { MessageBox.Show("Cascading dependency error or operational blocking encountered: " + ex.Message); }
            }
        }

        private void btnClearFields_Click(object sender, EventArgs e) => ClearAdminInputFields();

        private void dgvQuestions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvQuestions.CurrentRow == null || e.RowIndex < 0) return;
            DataGridViewRow row = dgvQuestions.CurrentRow;

            txtQuestionText.Text = row.Cells["QuestionText"].Value?.ToString();
            txtOptA.Text = row.Cells["OptionA"].Value?.ToString();
            txtOptB.Text = row.Cells["OptionB"].Value?.ToString();
            txtOptC.Text = row.Cells["OptionC"].Value?.ToString();
            txtOptD.Text = row.Cells["OptionD"].Value?.ToString();
            cmbCorrectOption.SelectedItem = row.Cells["CorrectOption"].Value?.ToString();
            numPoints.Value = Convert.ToDecimal(row.Cells["Points"].Value ?? 1);
            cmbSubjectAdmin.Text = row.Cells["SubjectName"].Value?.ToString();
        }

        private void ClearAdminInputFields()
        {
            txtQuestionText.Clear();
            txtOptA.Clear(); txtOptB.Clear(); txtOptC.Clear(); txtOptD.Clear();
            if (cmbCorrectOption.Items.Count > 0) cmbCorrectOption.SelectedIndex = 0;
            numPoints.Value = 1;
        }

        // ================= TAB 3: RUNTIME QUIZ INTERACTION METRICS =================
        private void btnStartQuiz_Click(object sender, EventArgs e)
        {
            if (cmbSubjectQuiz.SelectedValue == null) return;
            int targetSubjectId = Convert.ToInt32(cmbSubjectQuiz.SelectedValue);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string selectQuestions = "SELECT TOP 25 * FROM Questions WHERE SubjectId = @sub ORDER BY NEWID()";
                SqlCommand cmd = new SqlCommand(selectQuestions, conn);
                cmd.Parameters.AddWithValue("@sub", targetSubjectId);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No active question components discovered inside index selection criteria.", "Data Missing", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                quizQuestions = dt.AsEnumerable().ToList();
                userAnswers.Clear();
                currentQuestionIndex = 0;

                cmbSubjectQuiz.Enabled = false;
                btnStartQuiz.Enabled = false;

                DisplayActiveQuestionFrame();
            }
        }

        private void DisplayActiveQuestionFrame()
        {
            if (currentQuestionIndex < 0 || currentQuestionIndex >= quizQuestions.Count) return;

            DataRow currentQuestion = quizQuestions[currentQuestionIndex];
            lblQuestionDisplay.Text = $"Question {currentQuestionIndex + 1} of {quizQuestions.Count}:\n\n{currentQuestion["QuestionText"]}";

            rbOptA.Text = currentQuestion["OptionA"].ToString();
            rbOptB.Text = currentQuestion["OptionB"].ToString();
            rbOptC.Text = currentQuestion["OptionC"].ToString();
            rbOptD.Text = currentQuestion["OptionD"].ToString();

            // Deselect default active tracking controls safely
            quizTimer.Stop();
            rbOptA.Checked = rbOptB.Checked = rbOptC.Checked = rbOptD.Checked = false;

            // Restore state historical choices context configuration parameter map matching active index tree pointer
            int currentQId = Convert.ToInt32(currentQuestion["QuestionId"]);
            if (userAnswers.ContainsKey(currentQId))
            {
                string previouslyChosen = userAnswers[currentQId];
                if (previouslyChosen == "A") rbOptA.Checked = true;
                else if (previouslyChosen == "B") rbOptB.Checked = true;
                else if (previouslyChosen == "C") rbOptC.Checked = true;
                else if (previouslyChosen == "D") rbOptD.Checked = true;
            }

            btnPrevious.Enabled = (currentQuestionIndex > 0);

            if (currentQuestionIndex == quizQuestions.Count - 1)
            {
                btnNext.Visible = false;
                btnSubmitQuiz.Visible = true;
            }
            else
            {
                btnNext.Visible = true;
                btnSubmitQuiz.Visible = false;
            }

            timeAllocated = 30;
            lblTimer.Text = $"Time Remaining: {timeAllocated}s";
            quizTimer.Start();
        }

        private void CacheActiveRadioStateSelection()
        {
            if (quizQuestions.Count == 0 || currentQuestionIndex >= quizQuestions.Count) return;

            int currentQId = Convert.ToInt32(quizQuestions[currentQuestionIndex]["QuestionId"]);
            string chosenStr = null;

            if (rbOptA.Checked) chosenStr = "A";
            else if (rbOptB.Checked) chosenStr = "B";
            else if (rbOptC.Checked) chosenStr = "C";
            else if (rbOptD.Checked) chosenStr = "D";

            if (userAnswers.ContainsKey(currentQId))
                userAnswers[currentQId] = chosenStr;
            else if (chosenStr != null)
                userAnswers.Add(currentQId, chosenStr);
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            CacheActiveRadioStateSelection();
            currentQuestionIndex--;
            DisplayActiveQuestionFrame();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            CacheActiveRadioStateSelection();
            currentQuestionIndex++;
            DisplayActiveQuestionFrame();
        }

        private void quizTimer_Tick(object sender, EventArgs e)
        {
            timeAllocated--;
            lblTimer.Text = $"Time Remaining: {timeAllocated}s";

            if (timeAllocated <= 0)
            {
                quizTimer.Stop();
                CacheActiveRadioStateSelection();
                if (currentQuestionIndex < quizQuestions.Count - 1)
                {
                    currentQuestionIndex++;
                    DisplayActiveQuestionFrame();
                }
                else
                {
                    EvaluateExamPaperAndPushResults();
                }
            }
        }

        private void btnSubmitQuiz_Click(object sender, EventArgs e)
        {
            quizTimer.Stop();
            CacheActiveRadioStateSelection();
            EvaluateExamPaperAndPushResults();
        }

        private void EvaluateExamPaperAndPushResults()
        {
            if (quizQuestions.Count == 0) return;

            int totalQuestionsCount = quizQuestions.Count;
            int correctAnswersCount = 0;
            int maximumPossiblePoints = 0;
            int totalUserScoredPoints = 0;
            int targetSubjectId = Convert.ToInt32(quizQuestions[0]["SubjectId"]);

            DataTable breakdownCacheTable = new DataTable();
            breakdownCacheTable.Columns.Add("QuestionText");
            breakdownCacheTable.Columns.Add("YourChoice");
            breakdownCacheTable.Columns.Add("CorrectChoice");
            breakdownCacheTable.Columns.Add("StatusText");
            breakdownCacheTable.Columns.Add("PointsAwarded");

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlTransaction evaluationTransaction = null;
                try
                {
                    conn.Open();
                    evaluationTransaction = conn.BeginTransaction();

                    // Step A: Pre-calculate point tracking summary context schemas
                    foreach (DataRow questionRow in quizQuestions)
                    {
                        int questionId = Convert.ToInt32(questionRow["QuestionId"]);
                        int baseWeight = Convert.ToInt32(questionRow["Points"]);
                        string correctChoice = questionRow["CorrectOption"].ToString().Trim();
                        maximumPossiblePoints += baseWeight;

                        string studentChoice = null;
                        if (userAnswers.ContainsKey(questionId)) studentChoice = userAnswers[questionId];

                        bool verificationStatusFlag = (studentChoice != null && studentChoice.Equals(correctChoice, StringComparison.OrdinalIgnoreCase));
                        int calculatedScoreContribution = verificationStatusFlag ? baseWeight : 0;

                        if (verificationStatusFlag) correctAnswersCount++;
                        totalUserScoredPoints += calculatedScoreContribution;
                    }

                    // Step B: Push summary entry tracking metrics block inside QuizResults Table
                    string querySummaryInsert = @"INSERT INTO QuizResults (UserId, SubjectId, TotalQuestions, CorrectAnswers, TotalPoints, ScoredPoints, DateTaken) 
                                                  OUTPUT INSERTED.ResultId 
                                                  VALUES (@u, @sub, @tq, @ca, @tp, @sp, GETDATE())";

                    using (SqlCommand cmdSummary = new SqlCommand(querySummaryInsert, conn, evaluationTransaction))
                    {
                        cmdSummary.Parameters.AddWithValue("@u", loggedInUserId);
                        cmdSummary.Parameters.AddWithValue("@sub", targetSubjectId);
                        cmdSummary.Parameters.AddWithValue("@tq", totalQuestionsCount);
                        cmdSummary.Parameters.AddWithValue("@ca", correctAnswersCount);
                        cmdSummary.Parameters.AddWithValue("@tp", maximumPossiblePoints);
                        cmdSummary.Parameters.AddWithValue("@sp", totalUserScoredPoints);

                        currentActiveResultId = (int)cmdSummary.ExecuteScalar();
                    }

                    // Step C: Stream precise details to individual item logging collection structures
                    foreach (DataRow row in quizQuestions)
                    {
                        int qId = Convert.ToInt32(row["QuestionId"]);
                        int pts = Convert.ToInt32(row["Points"]);
                        string correctVal = row["CorrectOption"].ToString().Trim();
                        string selectedVal = userAnswers.ContainsKey(qId) ? userAnswers[qId] : null;

                        bool matches = (selectedVal != null && selectedVal.Equals(correctVal, StringComparison.OrdinalIgnoreCase));
                        int calculatedPointsEarned = matches ? pts : 0;

                        string detailsLogInsert = @"INSERT INTO QuizAnswers (ResultId, QuestionId, SelectedOption, IsCorrect, PointsEarned) 
                                                    VALUES (@rId, @qId, @sel, @isCorr, @ptsEarned)";

                        using (SqlCommand cmdDetail = new SqlCommand(detailsLogInsert, conn, evaluationTransaction))
                        {
                            cmdDetail.Parameters.AddWithValue("@rId", currentActiveResultId);
                            cmdDetail.Parameters.AddWithValue("@qId", qId);
                            cmdDetail.Parameters.AddWithValue("@sel", (object)selectedVal ?? DBNull.Value);
                            cmdDetail.Parameters.AddWithValue("@isCorr", matches ? 1 : 0);
                            cmdDetail.Parameters.AddWithValue("@ptsEarned", calculatedPointsEarned);
                            cmdDetail.ExecuteNonQuery();
                        }

                        breakdownCacheTable.Rows.Add(
                            row["QuestionText"].ToString(),
                            selectedVal ?? "SKIPPED",
                            correctVal,
                            matches ? "CORRECT" : "WRONG",
                            calculatedPointsEarned
                        );
                    }

                    evaluationTransaction.Commit();

                    // Route state flow control context variables to view breakdown layers
                    dgvResultBreakdown.DataSource = breakdownCacheTable;
                    tabControlMain.SelectedTab = tabPageResult;

                    MessageBox.Show($"Exam evaluation completed.\nFinal Score: {totalUserScoredPoints} / {maximumPossiblePoints} Points.", "Submission Executed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    try { evaluationTransaction?.Rollback(); } catch { /* Fallback execution handler */ }
                    MessageBox.Show("Transaction processing fatal error: " + ex.Message, "Execution Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // ================= TAB 4: METRICS INTERPRETATION ENGINE VIEW LAYER =================
        private void dgvResultBreakdown_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvResultBreakdown.Columns[e.ColumnIndex].Name == "StatusText" && e.Value != null)
            {
                string stateValueText = e.Value.ToString();
                if (stateValueText.Equals("CORRECT", StringComparison.OrdinalIgnoreCase))
                {
                    e.CellStyle.BackColor = Color.LightGreen;
                    e.CellStyle.ForeColor = Color.DarkGreen;
                }
                if (stateValueText.Equals("WRONG", StringComparison.OrdinalIgnoreCase))
                {
                    e.CellStyle.BackColor = Color.MistyRose;
                    e.CellStyle.ForeColor = Color.Red;
                }
            }
        }

        private void btnBackToHome_Click(object sender, EventArgs e)
        {
            cmbSubjectQuiz.Enabled = true;
            btnStartQuiz.Enabled = true;
            lblQuestionDisplay.Text = "Please pick a subject and initialize the quiz context.";
            rbOptA.Text = rbOptB.Text = rbOptC.Text = rbOptD.Text = "Options Frame Default State";
            btnSubmitQuiz.Visible = false;
            btnNext.Visible = true;

            tabControlMain.SelectedTab = tabPageQuiz;
        }

        // ================= TAB 5: HISTORICAL AUDITING METRICS ARCHIVES =================
        private void btnRefreshHistory_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string historyQuery = @"SELECT r.ResultId, u.Username, s.SubjectName, s.CourseCode, r.TotalQuestions, r.CorrectAnswers, r.TotalPoints, r.ScoredPoints, r.DateTaken 
                                            FROM QuizResults r 
                                            JOIN Users u ON r.UserId = u.UserId 
                                            JOIN Subjects s ON r.SubjectId = s.SubjectId ";

                    if (loggedInRole.Equals("Student", StringComparison.OrdinalIgnoreCase))
                    {
                        historyQuery += " WHERE r.UserId = @uId";
                    }
                    historyQuery += " ORDER BY r.DateTaken DESC";

                    SqlCommand cmd = new SqlCommand(historyQuery, conn);
                    if (loggedInRole.Equals("Student", StringComparison.OrdinalIgnoreCase))
                    {
                        cmd.Parameters.AddWithValue("@uId", loggedInUserId);
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvHistory.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to retrieve system historical archive metrics layers: " + ex.Message);
            }
        }
    }
}