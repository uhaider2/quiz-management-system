-- ============================================
-- QUIZ SYSTEM DATABASE SCRIPT (FULL / FINAL VERSION)
-- 5 Subjects | Course Codes | 25 Questions Each | Points per Question
-- + Real-time Result Tracking (QuizResults + QuizAnswers breakdown)
-- Run this anytime to reset/rebuild the entire database
-- ============================================

-- Step 1: Create Database (only if it doesn't exist)
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'QuizSystemDB')
BEGIN
    CREATE DATABASE QuizSystemDB;
END
GO

USE QuizSystemDB;
GO

-- ============================================
-- Step 2: Drop Tables (in correct order due to FKs)
-- ============================================
IF OBJECT_ID('QuizAnswers', 'U') IS NOT NULL DROP TABLE QuizAnswers;
IF OBJECT_ID('QuizResults', 'U') IS NOT NULL DROP TABLE QuizResults;
IF OBJECT_ID('Questions', 'U') IS NOT NULL DROP TABLE Questions;
IF OBJECT_ID('Subjects', 'U') IS NOT NULL DROP TABLE Subjects;
IF OBJECT_ID('Users', 'U') IS NOT NULL DROP TABLE Users;
GO

-- ============================================
-- Step 3: Create Tables
-- ============================================

-- Users Table
CREATE TABLE Users (
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL DEFAULT 'Student' -- 'Admin' or 'Student'
);
GO

-- Subjects Table (with CourseCode)
CREATE TABLE Subjects (
    SubjectId INT PRIMARY KEY IDENTITY(1,1),
    SubjectName VARCHAR(100) NOT NULL,
    CourseCode VARCHAR(20) NOT NULL
);
GO

-- Questions Table (with Points)
CREATE TABLE Questions (
    QuestionId INT PRIMARY KEY IDENTITY(1,1),
    SubjectId INT NOT NULL,
    QuestionText VARCHAR(500) NOT NULL,
    OptionA VARCHAR(200) NOT NULL,
    OptionB VARCHAR(200) NOT NULL,
    OptionC VARCHAR(200) NOT NULL,
    OptionD VARCHAR(200) NOT NULL,
    CorrectOption CHAR(1) NOT NULL, -- 'A', 'B', 'C', or 'D'
    Points INT NOT NULL DEFAULT 1,
    FOREIGN KEY (SubjectId) REFERENCES Subjects(SubjectId)
);
GO

-- QuizResults Table (Summary of each quiz attempt — tracks REAL points, not just count)
CREATE TABLE QuizResults (
    ResultId INT PRIMARY KEY IDENTITY(1,1),
    UserId INT NOT NULL,
    SubjectId INT NOT NULL,
    TotalQuestions INT NOT NULL,
    CorrectAnswers INT NOT NULL,
    TotalPoints INT NOT NULL,        -- Sum of points of ALL questions in this attempt
    ScoredPoints INT NOT NULL,       -- Sum of points the student actually earned
    DateTaken DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(UserId),
    FOREIGN KEY (SubjectId) REFERENCES Subjects(SubjectId)
);
GO

-- QuizAnswers Table (Question-wise breakdown for each attempt — for Review/Result tab)
CREATE TABLE QuizAnswers (
    AnswerId INT PRIMARY KEY IDENTITY(1,1),
    ResultId INT NOT NULL,            -- Which quiz attempt this belongs to
    QuestionId INT NOT NULL,
    SelectedOption CHAR(1) NULL,      -- What the student chose ('A','B','C','D', or NULL if skipped)
    IsCorrect BIT NOT NULL,           -- 1 = correct, 0 = wrong
    PointsEarned INT NOT NULL,        -- Points scored for this specific question (0 if wrong/skipped)
    FOREIGN KEY (ResultId) REFERENCES QuizResults(ResultId),
    FOREIGN KEY (QuestionId) REFERENCES Questions(QuestionId)
);
GO

-- ============================================
-- Step 4: Insert Users
-- ============================================
INSERT INTO Users (Username, Password, Role) VALUES
('admin', 'admin123', 'Admin'),
('student1', 'pass123', 'Student');
GO

-- ============================================
-- Step 5: Insert Subjects (with Course Codes)
-- ============================================
INSERT INTO Subjects (SubjectName, CourseCode) VALUES
('Discrete Structure', 'CS-201'),
('Data Structure', 'CS-202'),
('Cyber Security', 'CS-301'),
('Software Engineering', 'CS-302'),
('Database System', 'CS-303');
GO

-- ============================================
-- Step 6: Insert Questions
-- SubjectId: 1 = Discrete Structure, 2 = Data Structure,
--            3 = Cyber Security, 4 = Software Engineering, 5 = Database System
-- ============================================

-- ===================== DISCRETE STRUCTURE (SubjectId = 1) =====================
INSERT INTO Questions (SubjectId, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Points) VALUES
(1, 'What is a set with no elements called?', 'Universal Set', 'Empty Set', 'Subset', 'Power Set', 'B', 2),
(1, 'Which symbol represents "union" of two sets?', '∩', '∪', '⊂', '∈', 'B', 2),
(1, 'Which symbol represents "intersection" of two sets?', '∪', '∩', '⊆', '∀', 'B', 2),
(1, 'A relation that is reflexive, symmetric, and transitive is called?', 'Partial Order', 'Equivalence Relation', 'Function', 'Bijection', 'B', 3),
(1, 'How many subsets does a set with n elements have?', 'n', 'n^2', '2^n', '2n', 'C', 2),
(1, 'What is the negation of "p AND q"?', '¬p AND ¬q', '¬p OR ¬q', 'p OR q', 'p AND ¬q', 'B', 3),
(1, 'A graph with no cycles is called?', 'Tree', 'Loop', 'Cycle Graph', 'Complete Graph', 'A', 2),
(1, 'What is the contrapositive of "If p then q"?', 'If q then p', 'If ¬p then ¬q', 'If ¬q then ¬p', 'If q then ¬p', 'C', 3),
(1, 'Which of these is a propositional connective?', 'Σ', '∧', '∫', '∂', 'B', 2),
(1, 'A function that is both one-to-one and onto is called?', 'Injective', 'Surjective', 'Bijective', 'Constant', 'C', 2),
(1, 'In a graph, the degree of a vertex refers to?', 'Number of edges connected to it', 'Number of vertices', 'Shortest path length', 'Number of colors used', 'A', 2),
(1, 'Which rule states: if p→q and p is true, then q is true?', 'Modus Tollens', 'Modus Ponens', 'Disjunctive Syllogism', 'Hypothetical Syllogism', 'B', 3),
(1, 'A connected graph with no cycles having n vertices has how many edges?', 'n', 'n-1', 'n+1', '2n', 'B', 3),
(1, 'What does "P(A)" denote in set theory?', 'Probability of A', 'Power set of A', 'Product of A', 'Partition of A', 'B', 2),
(1, 'Which of the following is NOT a type of relation?', 'Reflexive', 'Symmetric', 'Recursive', 'Transitive', 'C', 2),
(1, 'The cardinality of an empty set is?', '1', 'Undefined', '0', 'Infinite', 'C', 1),
(1, 'A complete graph with n vertices is denoted as?', 'Cn', 'Kn', 'Gn', 'Tn', 'B', 2),
(1, 'Which logical operator is also called "exclusive or"?', 'AND', 'OR', 'XOR', 'NOT', 'C', 2),
(1, 'A binary relation R on set A is symmetric if?', 'aRb implies bRa', 'aRa always', 'aRb and bRc implies aRc', 'R has no elements', 'A', 3),
(1, 'How many elements are in the power set of {1,2,3}?', '6', '8', '9', '3', 'B', 2),
(1, 'A tautology is a statement that is?', 'Always false', 'Always true', 'Sometimes true', 'Never defined', 'B', 2),
(1, 'Which proof technique assumes the opposite of what you want to prove?', 'Direct Proof', 'Proof by Contradiction', 'Proof by Induction', 'Proof by Cases', 'B', 3),
(1, 'In graph theory, a path that visits every vertex exactly once is called?', 'Euler Path', 'Hamiltonian Path', 'Cycle', 'Spanning Tree', 'B', 3),
(1, 'What is the truth value of "p ∨ ¬p"?', 'Always False', 'Always True', 'Depends on p', 'Undefined', 'B', 2),
(1, 'A partial order relation must be?', 'Reflexive, Symmetric, Transitive', 'Reflexive, Antisymmetric, Transitive', 'Symmetric only', 'Transitive only', 'B', 3);

-- ===================== DATA STRUCTURE (SubjectId = 2) =====================
INSERT INTO Questions (SubjectId, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Points) VALUES
(2, 'Which data structure uses FIFO (First In First Out)?', 'Stack', 'Queue', 'Tree', 'Graph', 'B', 2),
(2, 'Which data structure uses LIFO (Last In First Out)?', 'Queue', 'Stack', 'Linked List', 'Array', 'B', 2),
(2, 'What is the time complexity of binary search?', 'O(n)', 'O(n^2)', 'O(log n)', 'O(1)', 'C', 3),
(2, 'Which data structure is used in recursion internally?', 'Queue', 'Stack', 'Array', 'Tree', 'B', 2),
(2, 'In a linked list, each node contains?', 'Only data', 'Only pointer', 'Data and pointer to next node', 'Only index', 'C', 2),
(2, 'What is the time complexity of accessing an array element by index?', 'O(n)', 'O(1)', 'O(log n)', 'O(n^2)', 'B', 2),
(2, 'Which traversal visits left subtree, root, then right subtree?', 'Preorder', 'Postorder', 'Inorder', 'Level order', 'C', 3),
(2, 'A complete binary tree with n nodes has a height of approximately?', 'n', 'n/2', 'log2(n)', 'n^2', 'C', 3),
(2, 'Which sorting algorithm has the best average case time complexity?', 'Bubble Sort', 'Quick Sort', 'Selection Sort', 'Insertion Sort', 'B', 3),
(2, 'A graph with weights assigned to edges is called?', 'Directed Graph', 'Weighted Graph', 'Simple Graph', 'Tree', 'B', 2),
(2, 'Which data structure is best for implementing a priority queue?', 'Array', 'Linked List', 'Heap', 'Stack', 'C', 3),
(2, 'What is the worst-case time complexity of Quick Sort?', 'O(n log n)', 'O(n)', 'O(n^2)', 'O(log n)', 'C', 3),
(2, 'Which data structure allows insertion and deletion from both ends?', 'Stack', 'Queue', 'Deque', 'Array', 'C', 2),
(2, 'In a hash table, a collision occurs when?', 'Two keys map to the same index', 'Table is empty', 'Key is not found', 'Table is full', 'A', 3),
(2, 'Which traversal of a tree uses a queue?', 'Inorder', 'Preorder', 'Postorder', 'Level order (BFS)', 'D', 3),
(2, 'What is the space complexity of an adjacency matrix for a graph with V vertices?', 'O(V)', 'O(V^2)', 'O(E)', 'O(1)', 'B', 3),
(2, 'A self-balancing binary search tree is also known as?', 'B-Tree', 'AVL Tree', 'Heap', 'Trie', 'B', 3),
(2, 'Which algorithm is used to find the shortest path in a graph?', 'DFS', 'Dijkstra''s Algorithm', 'Bubble Sort', 'Binary Search', 'B', 3),
(2, 'What does DFS stand for?', 'Depth First Search', 'Data Flow Search', 'Direct Find Search', 'Double First Search', 'A', 2),
(2, 'A circular linked list differs from a linear linked list because?', 'It has no head', 'Last node points back to first node', 'It has two heads', 'It cannot be traversed', 'B', 2),
(2, 'Which data structure is most efficient for implementing recursion-free DFS?', 'Queue', 'Stack', 'Array', 'Heap', 'B', 2),
(2, 'What is the time complexity of inserting an element at the beginning of an array?', 'O(1)', 'O(log n)', 'O(n)', 'O(n^2)', 'C', 2),
(2, 'A Trie data structure is commonly used for?', 'Sorting numbers', 'Storing and searching strings', 'Graph traversal', 'Matrix multiplication', 'B', 3),
(2, 'In Big-O notation, O(1) represents?', 'Linear time', 'Constant time', 'Logarithmic time', 'Exponential time', 'B', 2),
(2, 'Which data structure follows a hierarchical structure?', 'Array', 'Queue', 'Tree', 'Stack', 'C', 2);

-- ===================== CYBER SECURITY (SubjectId = 3) =====================
INSERT INTO Questions (SubjectId, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Points) VALUES
(3, 'What does CIA stand for in Cyber Security?', 'Central Intelligence Agency', 'Confidentiality, Integrity, Availability', 'Cyber Intelligence Analysis', 'Control, Identity, Access', 'B', 3),
(3, 'Which type of attack floods a server with traffic to make it unavailable?', 'Phishing', 'DDoS Attack', 'SQL Injection', 'Man in the Middle', 'B', 2),
(3, 'What is "phishing"?', 'A type of firewall', 'A method to encrypt data', 'A fraudulent attempt to obtain sensitive information', 'A type of antivirus', 'C', 2),
(3, 'Which of the following is a strong password practice?', 'Using "12345"', 'Using your name', 'Using a mix of letters, numbers, symbols', 'Using the same password everywhere', 'C', 2),
(3, 'What does VPN stand for?', 'Virtual Private Network', 'Verified Public Network', 'Virtual Protected Node', 'Virus Protection Network', 'A', 1),
(3, 'A firewall is used to?', 'Speed up internet', 'Filter network traffic', 'Store passwords', 'Compress files', 'B', 2),
(3, 'What is "malware"?', 'Hardware malfunction', 'Malicious software', 'A network protocol', 'Encryption method', 'B', 1),
(3, 'Which attack involves inserting malicious SQL statements into input fields?', 'XSS', 'SQL Injection', 'DDoS', 'Phishing', 'B', 3),
(3, 'What is "encryption"?', 'Deleting data permanently', 'Converting data into unreadable format for security', 'Compressing files', 'Copying data', 'B', 2),
(3, 'A "Trojan Horse" in cyber security refers to?', 'A type of firewall', 'Malware disguised as legitimate software', 'A network cable', 'A secure password', 'B', 2),
(3, 'What does "2FA" stand for?', 'Two-Factor Authentication', 'Two File Access', 'Second Firewall Activation', 'Two Function Algorithm', 'A', 2),
(3, 'Which of these is an example of social engineering attack?', 'Buffer Overflow', 'Phishing Email', 'Port Scanning', 'Brute Force', 'B', 2),
(3, 'What is the purpose of a "honeypot" in cyber security?', 'To encrypt data', 'To attract and trap attackers', 'To speed up network', 'To store backups', 'B', 3),
(3, 'Which protocol is used for secure web browsing?', 'HTTP', 'FTP', 'HTTPS', 'SMTP', 'C', 1),
(3, 'What is "ransomware"?', 'Software that speeds up your PC', 'Malware that locks data and demands payment', 'A type of firewall', 'An antivirus tool', 'B', 2),
(3, 'Brute force attack is used to?', 'Guess passwords by trying many combinations', 'Encrypt files', 'Scan for viruses', 'Block websites', 'A', 2),
(3, 'What is the main goal of "penetration testing"?', 'To damage a system', 'To find vulnerabilities before attackers do', 'To slow down a network', 'To create malware', 'B', 3),
(3, 'What does "DoS" stand for?', 'Denial of Service', 'Disk Operating System', 'Data on Server', 'Direct Online Search', 'A', 2),
(3, 'A "zero-day vulnerability" refers to?', 'A bug fixed immediately', 'A flaw unknown to the vendor with no patch yet', 'A virus older than a day', 'A type of firewall', 'B', 3),
(3, 'Which of these best describes "spyware"?', 'Software that secretly monitors user activity', 'A type of antivirus', 'A network router', 'A backup tool', 'A', 2),
(3, 'What is the function of an "Intrusion Detection System (IDS)"?', 'To encrypt files', 'To monitor and detect suspicious network activity', 'To compress data', 'To create backups', 'B', 3),
(3, 'Which of the following is the safest way to handle suspicious email attachments?', 'Open immediately', 'Forward to friends', 'Do not open, verify sender first', 'Reply with personal info', 'C', 2),
(3, 'What does "patch management" refer to?', 'Updating software to fix vulnerabilities', 'Repairing hardware', 'Creating new passwords', 'Designing firewalls', 'A', 2),
(3, 'Cross-Site Scripting (XSS) attacks target?', 'Database servers only', 'Web applications by injecting malicious scripts', 'Hardware devices', 'Email servers only', 'B', 3),
(3, 'What is the purpose of "hashing" in security?', 'To encrypt and decrypt data reversibly', 'To create a fixed-size irreversible representation of data', 'To compress large files', 'To speed up networks', 'B', 3);

-- ===================== SOFTWARE ENGINEERING (SubjectId = 4) =====================
INSERT INTO Questions (SubjectId, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Points) VALUES
(4, 'What does SDLC stand for?', 'Software Design Life Cycle', 'System Development Life Cycle', 'Software Development Life Cycle', 'Structured Design Logic Cycle', 'C', 2),
(4, 'Which model follows a strict sequential approach?', 'Agile Model', 'Waterfall Model', 'Spiral Model', 'Prototype Model', 'B', 2),
(4, 'What is the main focus of the Agile methodology?', 'Heavy documentation', 'Iterative development and flexibility', 'Strict sequential phases', 'No customer involvement', 'B', 2),
(4, 'What does "UML" stand for?', 'Unified Modeling Language', 'Universal Markup Language', 'User Modeling Logic', 'Unified Machine Language', 'A', 2),
(4, 'Which diagram shows the interaction between objects over time?', 'Class Diagram', 'Sequence Diagram', 'Use Case Diagram', 'Activity Diagram', 'B', 3),
(4, 'What is "software testing"?', 'Writing new code', 'Verifying software meets requirements and is free of defects', 'Designing UI', 'Deploying software', 'B', 2),
(4, 'Which testing checks individual units/components of software?', 'System Testing', 'Unit Testing', 'Acceptance Testing', 'Integration Testing', 'B', 2),
(4, 'What is a "use case diagram" used for?', 'Showing database structure', 'Representing system functionality from user perspective', 'Showing class relationships', 'Network topology', 'B', 2),
(4, 'In Agile, a short development cycle is called?', 'Milestone', 'Sprint', 'Phase', 'Increment Loop', 'B', 2),
(4, 'What does "requirement gathering" involve?', 'Writing final code', 'Collecting needs and expectations from stakeholders', 'Testing the software', 'Deploying the system', 'B', 2),
(4, 'Which model is best suited for projects with high risk and changing requirements?', 'Waterfall Model', 'Spiral Model', 'V-Model', 'Big Bang Model', 'B', 3),
(4, 'What is "software maintenance"?', 'Initial development phase', 'Modifying software after delivery to fix issues or improve it', 'Writing test cases', 'Designing architecture', 'B', 2),
(4, 'Which of these is a non-functional requirement?', 'Login feature', 'Search functionality', 'System performance/speed', 'Add to cart button', 'C', 3),
(4, 'What is "version control" used for?', 'Tracking and managing changes to code over time', 'Compiling code', 'Testing UI', 'Designing databases', 'A', 2),
(4, 'In software engineering, "coupling" refers to?', 'Degree of interdependence between modules', 'Number of bugs in code', 'Speed of execution', 'Size of the codebase', 'A', 3),
(4, 'What does high cohesion in a module indicate?', 'Module does many unrelated things', 'Module focuses on a single well-defined task', 'Module has many bugs', 'Module is poorly documented', 'B', 3),
(4, 'Which document describes what the system should do, agreed upon by stakeholders?', 'Test Plan', 'Software Requirement Specification (SRS)', 'Source Code', 'Deployment Guide', 'B', 2),
(4, 'What is a "class diagram" used to represent?', 'Sequence of events', 'Static structure of classes and their relationships', 'User workflows', 'Network connections', 'B', 2),
(4, 'Which type of testing is done by actual end users before final release?', 'Unit Testing', 'Acceptance Testing', 'Integration Testing', 'Regression Testing', 'B', 2),
(4, 'What is "regression testing"?', 'Testing only new features', 'Re-testing software after changes to ensure nothing broke', 'Testing UI design', 'Testing hardware', 'B', 3),
(4, 'In the Waterfall model, can you go back to a previous phase easily?', 'Yes, anytime', 'No, it is difficult once a phase is complete', 'Only in testing phase', 'Only in design phase', 'B', 2),
(4, 'What does "scope creep" refer to in project management?', 'Uncontrolled changes/growth in project scope', 'Reducing project budget', 'Finishing project early', 'Hiring more developers', 'A', 3),
(4, 'Which is an example of a functional requirement?', 'System should load within 2 seconds', 'User should be able to reset password', 'System should be available 99.9% of time', 'System should be scalable', 'B', 2),
(4, 'What is the purpose of a "Gantt chart" in project management?', 'Show class relationships', 'Visualize project schedule and timeline', 'Show database tables', 'Show network architecture', 'B', 2),
(4, 'What is "pair programming" in Agile/XP practices?', 'Two developers working together at one workstation', 'Testing two modules at once', 'Running two servers', 'Using two programming languages', 'A', 2);

-- ===================== DATABASE SYSTEM (SubjectId = 5) =====================
INSERT INTO Questions (SubjectId, QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Points) VALUES
(5, 'What does SQL stand for?', 'Structured Query Language', 'Simple Query Language', 'Standard Question Language', 'System Query Logic', 'A', 1),
(5, 'Which command is used to retrieve data from a database?', 'INSERT', 'UPDATE', 'SELECT', 'DELETE', 'C', 1),
(5, 'What is a "primary key"?', 'A key that can have duplicate values', 'A unique identifier for each record in a table', 'A key used only for foreign tables', 'A key with no constraints', 'B', 2),
(5, 'What does "foreign key" represent?', 'A key from another country''s database', 'A field that links to the primary key of another table', 'A duplicate primary key', 'An encrypted key', 'B', 2),
(5, 'Which normal form removes partial dependency?', '1NF', '2NF', '3NF', 'BCNF', 'B', 3),
(5, 'What is "normalization" in databases?', 'Increasing data redundancy', 'Organizing data to reduce redundancy', 'Encrypting database', 'Deleting old data', 'B', 2),
(5, 'Which SQL clause is used to filter rows?', 'ORDER BY', 'GROUP BY', 'WHERE', 'HAVING', 'C', 1),
(5, 'What is a "JOIN" used for in SQL?', 'Deleting tables', 'Combining rows from two or more tables based on a related column', 'Creating indexes', 'Backing up data', 'B', 2),
(5, 'Which type of JOIN returns only matching rows from both tables?', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN', 'FULL OUTER JOIN', 'C', 2),
(5, 'What is an "ER Diagram"?', 'A diagram showing network architecture', 'A diagram showing entities and relationships in a database', 'A flowchart for code logic', 'A UML class diagram', 'B', 2),
(5, 'What is the purpose of a "transaction" in DBMS?', 'To delete a database', 'A sequence of operations performed as a single logical unit of work', 'To create backups', 'To encrypt data', 'B', 3),
(5, 'What does ACID stand for in database transactions?', 'Atomicity, Consistency, Isolation, Durability', 'Access, Control, Identity, Data', 'Authentication, Cache, Index, Data', 'Atomic, Cache, Isolation, Data', 'A', 3),
(5, 'Which command is used to remove a table completely from database?', 'DELETE', 'TRUNCATE', 'DROP', 'REMOVE', 'C', 2),
(5, 'What is the difference between DELETE and TRUNCATE?', 'No difference', 'DELETE can use WHERE clause, TRUNCATE removes all rows without condition', 'TRUNCATE is slower', 'DELETE removes table structure too', 'B', 3),
(5, 'What is an "index" in a database used for?', 'To slow down queries', 'To speed up data retrieval', 'To delete duplicate rows', 'To encrypt tables', 'B', 2),
(5, 'Which SQL statement is used to add new data into a table?', 'UPDATE', 'INSERT', 'ALTER', 'SELECT', 'B', 1),
(5, 'What is a "view" in SQL?', 'A physical table', 'A virtual table based on the result of a SQL query', 'A type of index', 'A stored procedure', 'B', 2),
(5, 'Which keyword is used to sort query results?', 'GROUP BY', 'ORDER BY', 'WHERE', 'HAVING', 'B', 1),
(5, 'What does DDL stand for?', 'Data Definition Language', 'Data Display Language', 'Database Deletion Logic', 'Data Driven Language', 'A', 2),
(5, 'What does DML stand for?', 'Database Management Logic', 'Data Manipulation Language', 'Direct Memory Language', 'Data Display Logic', 'B', 2),
(5, 'Which constraint ensures a column cannot have duplicate values?', 'CHECK', 'UNIQUE', 'DEFAULT', 'FOREIGN KEY', 'B', 2),
(5, 'What is a "stored procedure"?', 'A precompiled collection of SQL statements stored in the database', 'A type of index', 'A database backup', 'A network protocol', 'A', 2),
(5, 'In database terms, what is a "deadlock"?', 'A locked database file', 'A situation where two transactions wait for each other indefinitely', 'A corrupted table', 'A type of join', 'B', 3),
(5, 'What does "GROUP BY" do in SQL?', 'Sorts data alphabetically', 'Groups rows sharing a property so aggregate functions can be applied', 'Deletes grouped rows', 'Filters rows individually', 'B', 2),
(5, 'Which of the following is a NoSQL database?', 'MySQL', 'SQL Server', 'MongoDB', 'Oracle', 'C', 2);

GO

-- ============================================
-- Step 7: Verify Data
-- ============================================
SELECT * FROM Users;
SELECT * FROM Subjects;
SELECT * FROM Questions ORDER BY SubjectId;
SELECT * FROM QuizResults;
SELECT * FROM QuizAnswers;

-- Quick check: count of questions per subject (should be 25 each) + total possible points
SELECT s.SubjectName, s.CourseCode, COUNT(q.QuestionId) AS TotalQuestions, SUM(q.Points) AS TotalPossiblePoints
FROM Subjects s
LEFT JOIN Questions q ON s.SubjectId = q.SubjectId
GROUP BY s.SubjectName, s.CourseCode;
GO

-- ============================================
-- Step 8: Example queries you'll use in C# later (for reference only)
-- ============================================

-- A) Get a student's full result summary
-- SELECT * FROM QuizResults WHERE UserId = @UserId ORDER BY DateTaken DESC;

-- B) Get question-wise breakdown for one specific attempt (Result/Review tab)
-- SELECT qa.AnswerId, q.QuestionText, q.OptionA, q.OptionB, q.OptionC, q.OptionD,
--        qa.SelectedOption, q.CorrectOption, qa.IsCorrect, qa.PointsEarned, q.Points AS MaxPoints
-- FROM QuizAnswers qa
-- JOIN Questions q ON qa.QuestionId = q.QuestionId
-- WHERE qa.ResultId = @ResultId;

-- C) Leaderboard (top scorers per subject, by points)
-- SELECT u.Username, s.SubjectName, r.ScoredPoints, r.TotalPoints, r.DateTaken
-- FROM QuizResults r
-- JOIN Users u ON r.UserId = u.UserId
-- JOIN Subjects s ON r.SubjectId = s.SubjectId
-- ORDER BY r.ScoredPoints DESC;
GO